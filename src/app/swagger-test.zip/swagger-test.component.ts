import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { forkJoin, Observable, of, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ClientListModel, ClientModel, ServiceListModel } from './models';
import { SwaggerService } from './swagger-service.service';

@Component({
  selector: 'app-swagger-test',
  templateUrl: './swagger-test.component.html',
  styleUrls: ['./swagger-test.component.scss']
})
export class SwaggerTestComponent implements OnInit, OnDestroy {
  swaggerForm: FormGroup;
  clientList: ClientListModel[];
  serviceList: ServiceListModel[];
  serviceList$: Observable<ServiceListModel[]>;
  currentClientId: number;

  isShowClientDetail = false;

  private _unsubscribeAll: Subject<any>;
  isSpinner = true;
  isInvalidErrors = false;
  errorDescription: string;

  constructor(
    private fb: FormBuilder,
    private swaggerService: SwaggerService
  ) { }

  ngOnInit(): void {
    const clientData = this.swaggerService.getClients();
    const serviceData = this.swaggerService.getServices();
    forkJoin([clientData, serviceData]).pipe(takeUntil(this._unsubscribeAll)).subscribe(([clientListRes, serviceListRes]) => {
      this.clientList = [...clientListRes.data];
      this.serviceList = [...serviceListRes];
      this.serviceList$ = of(this.serviceList);
      this.isSpinner = false;
    }, error => {
      alert('Server Error Occured!');
    });

  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }

  initForm(data: ClientModel): void {
    this.swaggerForm = this.fb.group({
      client: [data.name, [Validators.required]],
      services: [data.services[0], Validators.required]
    });
  }

  changeClient(e) {
    this.currentClientId = e.target.value;
    this.isShowClientDetail = false;
    this.swaggerService.getClient(e.target.value).pipe(takeUntil(this._unsubscribeAll)).subscribe(res => {
      if (res.status === 200) {
        this.isShowClientDetail = true;
        this.initForm(res.data);
      } else {
        alert('error occured');
      }
    })
  }

  changeService(e) {
    this.serviceID.setValue(e.target.value, {
      onlySelf: true
    })
  }

  get serviceID() {
    return this.swaggerForm.get('services');
  }

  updateClient(): void {
    const body = {
      id: this.currentClientId,
      name: this.swaggerForm.value.client,
      services: this.swaggerForm.value.services
    }

    this.swaggerService.updateClient(body).pipe(takeUntil(this._unsubscribeAll)).subscribe(res => {
      if (res.status === 200) {
        this.isInvalidErrors = false;
        this.swaggerForm.get('client').setValue(res.data.name);
      } else {
        this.isInvalidErrors = true;
        this.errorDescription = res.description;
      }
    }, error => {
      this.isInvalidErrors = true;
      this.errorDescription = 'Server Error Occured!';
    })
  }

  trackByFn(index, item): number {
    return index;
  }
}
