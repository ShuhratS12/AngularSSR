import { TestBed } from '@angular/core/testing';

import { SwaggerServiceService } from './swagger-service.service';

describe('SwaggerServiceService', () => {
  let service: SwaggerServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SwaggerServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
