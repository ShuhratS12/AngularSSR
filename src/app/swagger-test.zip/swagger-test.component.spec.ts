import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SwaggerTestComponent } from './swagger-test.component';

describe('SwaggerTestComponent', () => {
  let component: SwaggerTestComponent;
  let fixture: ComponentFixture<SwaggerTestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SwaggerTestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SwaggerTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
