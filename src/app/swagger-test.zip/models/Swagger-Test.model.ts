export interface ClientListModel {
  id: number,
  name: string
}

export interface ClientModel {
  id: number,
  name: string,
  services: number[]
}

export interface ServiceListModel {
  id: number,
  name: string
}
