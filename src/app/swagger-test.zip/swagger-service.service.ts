import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { ClientListModel, ClientModel, ServiceListModel } from './models';

@Injectable({
  providedIn: 'root'
})
export class SwaggerService {
  baseURL = 'http://161.97.131.248/swagger/api';

  constructor(private _httpClient: HttpClient,) { }

  getClients(): Observable<any> {
    return this._httpClient.get<ClientListModel[]>(`${this.baseURL}/Clients/GetClients`);
  }

  getClient(clientId: number): Observable<any> {
    return this._httpClient.get<ClientModel[]>(`${this.baseURL}/Clients/UpdateClients/${clientId}`);
  }

  updateClient(body: ClientModel): Observable<any> {
    return this._httpClient.post<ClientModel[]>(`${this.baseURL}/Clients/UpdateClients`, body);
  }

  getServices(): Observable<any> {
    return this._httpClient.get<ServiceListModel[]>(`${this.baseURL}/Services/GetServices`);
  }
}
